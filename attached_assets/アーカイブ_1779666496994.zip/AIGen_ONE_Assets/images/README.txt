このフォルダには、LP で使う 13枚の画像が入ります。

画像はまだダウンロードされていません。
1つ上のディレクトリで以下を実行してください：

Mac/Linux:   ./download-images.sh
Windows:     .\download-images.ps1

すべて Unsplash の商用利用OK・帰属表示不要な画像です。

#!/usr/bin/env bash
# ===================================================================
# AIGen ONE LP - 画像一括ダウンロードスクリプト
# ===================================================================
# 使い方:
#   1. このファイルがあるディレクトリで実行
#   2. ./images/ に全画像（13枚）がダウンロードされます
#
# 必要なもの: curl （macOS/Linuxは標準搭載、Windowsは Git Bash 等）
#
# すべての画像は Unsplash（商用利用無料・帰属表示不要）から取得
# https://unsplash.com/license
# ===================================================================

set -e

mkdir -p images

# 画像リスト：'ファイル名|URL' の形式で1行ずつ
# （Mac標準bash 3.x でも動くよう、連想配列は使わない）
IMAGES="hero-main.jpg|https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=80
hero-sub.jpg|https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=800&q=80
problem-bg.jpg|https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?auto=format&fit=crop&w=1600&q=80
concept.jpg|https://images.unsplash.com/photo-1604328698692-f76ea9498e76?auto=format&fit=crop&w=1000&q=80
target.jpg|https://images.unsplash.com/photo-1573497491208-6b1acb260507?auto=format&fit=crop&w=1000&q=80
security-bg.jpg|https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80
cta-bg.jpg|https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1600&q=80
feature-01-customer.jpg|https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?auto=format&fit=crop&w=800&q=80
feature-02-tasks.jpg|https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?auto=format&fit=crop&w=800&q=80
feature-03-inventory.jpg|https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&w=800&q=80
feature-04-knowledge.jpg|https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=800&q=80
feature-05-security.jpg|https://images.unsplash.com/photo-1614064641938-3bbee52942c7?auto=format&fit=crop&w=800&q=80
feature-06-integration.jpg|https://images.unsplash.com/photo-1543286386-713bdd548da4?auto=format&fit=crop&w=800&q=80"

echo ""
echo "==========================================="
echo "  AIGen ONE - 画像ダウンロード開始"
echo "==========================================="
echo ""

TOTAL=13
COUNT=0
FAILED=0

# 1行ずつ処理（空行はスキップ）
while IFS='|' read -r filename url; do
  # 空行スキップ
  [ -z "$filename" ] && continue
  [ -z "$url" ] && continue

  COUNT=$((COUNT + 1))
  filepath="images/$filename"

  printf "[%2d/%d] %-32s ... " "$COUNT" "$TOTAL" "$filename"

  if curl -sSL --max-time 30 -o "$filepath" "$url" 2>/dev/null; then
    # ファイルサイズ取得（Mac/Linux両対応）
    if [ "$(uname)" = "Darwin" ]; then
      size=$(stat -f%z "$filepath" 2>/dev/null || echo 0)
    else
      size=$(stat -c%s "$filepath" 2>/dev/null || echo 0)
    fi

    if [ "$size" -gt 1000 ]; then
      printf "✓ (%d KB)\n" "$((size / 1024))"
    else
      printf "✗ サイズが小さい (%d bytes)\n" "$size"
      FAILED=$((FAILED + 1))
    fi
  else
    printf "✗ ダウンロード失敗\n"
    FAILED=$((FAILED + 1))
  fi
done <<EOF
$IMAGES
EOF

echo ""
echo "==========================================="
SUCCESS=$((COUNT - FAILED))
if [ "$FAILED" -eq 0 ] && [ "$COUNT" -gt 0 ]; then
  echo "  ✓ 完了：${COUNT}枚すべてダウンロード成功"
elif [ "$COUNT" -eq 0 ]; then
  echo "  ✗ エラー：1枚も処理されませんでした"
else
  echo "  ⚠ 完了：${COUNT}枚中 ${SUCCESS}枚成功 / ${FAILED}枚失敗"
  echo ""
  echo "  失敗した画像は手動で取得するか、別の画像に差し替えてください。"
fi
echo "==========================================="
echo ""

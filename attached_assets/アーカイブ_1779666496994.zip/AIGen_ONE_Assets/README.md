# AIGen ONE - LP デプロイアセット一式

「話すだけで、自社のシステムが、できる。」企業向けAIプラットフォーム AIGen ONE のランディングページ一式です。

---

## 📁 構成

```
AIGen_ONE_Assets/
├── index.html                  # LP本体（メインファイル）
├── images/                     # 画像フォルダ（要：取得手順を実行）
├── download-images.sh          # 画像一括ダウンロード（Mac/Linux）
├── download-images.ps1         # 画像一括ダウンロード（Windows）
├── AIGen_ONE_Pitch.pptx        # 提案用スライド（10枚）
├── brand.md                    # ブランドガイド（色・フォント）
└── README.md                   # このファイル
```

---

## 🚀 デプロイ手順

### ステップ1：画像をダウンロード

LP本体は完成済みですが、写真は **Unsplash から別途取得**する必要があります（ライセンスはすべて商用利用無料・帰属表示不要）。

**Mac / Linux:**
```bash
cd AIGen_ONE_Assets
chmod +x download-images.sh
./download-images.sh
```

**Windows (PowerShell):**
```powershell
cd AIGen_ONE_Assets
.\download-images.ps1
```

→ `images/` フォルダに 13 枚の画像（合計 約 3-5MB）がダウンロードされます。

### ステップ2：動作確認（ローカル）

`index.html` をブラウザで開くだけで表示できます。
画像が表示されない場合は、ステップ1が完了しているか確認してください。

### ステップ3：サーバーにアップロード

`AIGen_ONE_Assets/` フォルダの中身をまるごと、サーバーの公開ディレクトリにアップロードしてください。

例：
```
example.com/
└── lp/
    ├── index.html
    └── images/
        ├── hero-main.jpg
        └── ...
```

`https://example.com/lp/` でアクセス可能になります。

---

## 🖼️ 画像の差し替え

ファイル名はそのままで、別の画像に差し替えれば LP に反映されます。

| ファイル名 | 用途 | 推奨サイズ |
|---|---|---|
| `hero-main.jpg` | ヒーローのメイン画像 | 1200×680 |
| `hero-sub.jpg` | ヒーローのサブ画像 | 800×450 |
| `problem-bg.jpg` | 課題セクション背景 | 1600×900 |
| `concept.jpg` | 使い方セクション | 1000×600 |
| `target.jpg` | おすすめユーザーセクション | 1000×600 |
| `security-bg.jpg` | セキュリティセクション背景 | 1200×800 |
| `cta-bg.jpg` | CTA セクション背景 | 1600×900 |
| `feature-01-customer.jpg` | 機能1：顧客管理 | 800×450 |
| `feature-02-tasks.jpg` | 機能2：業務管理 | 800×450 |
| `feature-03-inventory.jpg` | 機能3：在庫・受発注 | 800×450 |
| `feature-04-knowledge.jpg` | 機能4：社内検索 | 800×450 |
| `feature-05-security.jpg` | 機能5：セキュリティ | 800×450 |
| `feature-06-integration.jpg` | 機能6：既存システム連携 | 800×450 |

---

## ✏️ コンテンツの修正

`index.html` を開けば、HTMLタグの中に日本語テキストが直接書かれています。
テキストエディタ（VSCode, Sublime Text, メモ帳等）で開いて、書き換えて保存するだけで反映されます。

### よく変更したい箇所

| 検索ワード（Ctrl+F） | 内容 |
|---|---|
| `AIGen ONE` | 製品名 |
| `話すだけで、` | ヒーローのキャッチコピー |
| `資料を請求する` | CTAボタンの文言 |
| `<a href="#">` | リンク先（資料請求フォームのURL等） |
| `© 2026` | フッターのコピーライト |

---

## 🎨 デザイン仕様

詳細は `brand.md` を参照。

- **配色**: ネイビー `#0A1628` × ウォームゴールド `#B8864A` × オフホワイト `#F5F1EA`
- **フォント**: Noto Serif JP（見出し）+ Noto Sans JP（本文）+ Cormorant Garamond（英字）
- **レスポンシブ**: 1024px・640px でブレイクポイント
- **アニメーション**: スクロール時の fade-up（IntersectionObserver）

---

## 🛠️ 技術仕様

- 単一HTMLファイル（外部CSS・JSなし、フレームワーク非依存）
- 依存：Google Fonts（CDN経由で自動読み込み）
- ブラウザ対応：モダンブラウザ全般（Chrome, Safari, Firefox, Edge）
- 動作要件：JavaScriptオン（fade-upアニメーション用、なくても表示は可能）

---

## 📜 ライセンス・帰属

- **HTML/CSS/JS**: 自由に使用・改変可
- **画像**: すべて [Unsplash License](https://unsplash.com/license) に基づき、商用利用無料・帰属表示不要
- **フォント**: Google Fonts（オープンソース）

---

## ❓ トラブルシューティング

**画像が表示されない**
→ `download-images.sh` または `.ps1` を実行してください。

**フォントが崩れる**
→ Google Fontsへのアクセスをファイアウォール等で制限していないか確認してください。
オフラインで使う場合は、Google Fontsのフォントファイルをサーバーにホストして読み込ませてください。

**`./download-images.sh: Permission denied`**
→ `chmod +x download-images.sh` を実行してください。

**Windowsでスクリプトが実行できない**
→ PowerShellを管理者で開き、以下を実行：
```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

---

Made with Claude. 2026.

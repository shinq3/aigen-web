# ===================================================================
# AIGen ONE LP - 画像一括ダウンロードスクリプト (Windows / PowerShell)
# ===================================================================
# 使い方:
#   1. PowerShell をこのフォルダで開く
#   2. 実行: .\download-images.ps1
#      （初回は実行ポリシーで止まる場合あり：
#       PowerShell を「管理者として実行」して
#       Set-ExecutionPolicy -Scope CurrentUser RemoteSigned）
#
# 画像はすべて Unsplash（商用利用無料・帰属表示不要）から取得
# https://unsplash.com/license
# ===================================================================

$ErrorActionPreference = "Continue"

if (-not (Test-Path "images")) {
    New-Item -ItemType Directory -Path "images" | Out-Null
}

$images = @{
    "hero-main.jpg"               = "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=1200&q=80"
    "hero-sub.jpg"                = "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&w=800&q=80"
    "problem-bg.jpg"              = "https://images.unsplash.com/photo-1497032628192-86f99bcd76bc?auto=format&fit=crop&w=1600&q=80"
    "concept.jpg"                 = "https://images.unsplash.com/photo-1604328698692-f76ea9498e76?auto=format&fit=crop&w=1000&q=80"
    "target.jpg"                  = "https://images.unsplash.com/photo-1573497491208-6b1acb260507?auto=format&fit=crop&w=1000&q=80"
    "security-bg.jpg"             = "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1200&q=80"
    "cta-bg.jpg"                  = "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1600&q=80"
    "feature-01-customer.jpg"     = "https://images.unsplash.com/photo-1573164713714-d95e436ab8d6?auto=format&fit=crop&w=800&q=80"
    "feature-02-tasks.jpg"        = "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?auto=format&fit=crop&w=800&q=80"
    "feature-03-inventory.jpg"    = "https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&w=800&q=80"
    "feature-04-knowledge.jpg"    = "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=800&q=80"
    "feature-05-security.jpg"     = "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?auto=format&fit=crop&w=800&q=80"
    "feature-06-integration.jpg"  = "https://images.unsplash.com/photo-1543286386-713bdd548da4?auto=format&fit=crop&w=800&q=80"
}

Write-Host ""
Write-Host "==========================================="
Write-Host "  AIGen ONE - 画像ダウンロード開始"
Write-Host "==========================================="
Write-Host ""

$total = $images.Count
$count = 0
$failed = 0

foreach ($entry in $images.GetEnumerator()) {
    $count++
    $filename = $entry.Key
    $url = $entry.Value
    $path = "images/$filename"

    Write-Host -NoNewline ("[{0,2}/{1}] {2,-32} ... " -f $count, $total, $filename)

    try {
        Invoke-WebRequest -Uri $url -OutFile $path -UseBasicParsing -ErrorAction Stop
        $size = (Get-Item $path).Length
        if ($size -gt 1000) {
            Write-Host ("✓ ({0} KB)" -f [Math]::Round($size / 1024))
        } else {
            Write-Host "✗ サイズが小さい"
            $failed++
        }
    } catch {
        Write-Host "✗ ダウンロード失敗"
        $failed++
    }
}

Write-Host ""
Write-Host "==========================================="
if ($failed -eq 0) {
    Write-Host "  ✓ 完了：${total}枚すべてダウンロード成功"
} else {
    Write-Host "  ⚠ 完了：${total}枚中 $($total - $failed)枚成功 / ${failed}枚失敗"
}
Write-Host "==========================================="
Write-Host ""
